class Sample_2_Class
{
	public:

    void displayResult();
};
