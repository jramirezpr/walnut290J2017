#include <iostream>
using namespace std;

#include "Sample_2_Class.h"

void Sample_2_Class::displayResult()
{
   cout << "Successful build of Sample_2 Executable" << endl;
}
