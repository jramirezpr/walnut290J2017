#include <iostream>
using namespace std;
int main()
{
	cout << "Successful build of Sample_1 Executable" << endl;
}
