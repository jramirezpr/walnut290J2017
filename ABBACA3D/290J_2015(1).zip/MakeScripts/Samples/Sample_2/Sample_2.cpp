#include "Sample_2_Class.h"

// This example executable creates an instance of the Sample_2_Class
// and then invokes it's displayResult member function 
// 
int main()
{
	Sample_2_Class sample_2_Class;
    sample_2_Class.displayResult();
    return 0;
}
